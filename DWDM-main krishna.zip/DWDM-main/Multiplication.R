num1=as.integer(readline(prompt = "Enter the num 1:"))
num2 =as.integer(readline(prompt = "Enter a number2:"))
mul=num1*num2
print((paste("Multiplication:",mul)))
