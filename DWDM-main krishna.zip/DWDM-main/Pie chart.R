a <- c(80,70,50,60,70,100)
result <- (pie(a,main="piechart",labels =c( "student 1","student 2","student 3","student 4","student 5","student 6"),
                    col = c("red", "orange", "yellow", "blue", "green","black")))
print(result)





