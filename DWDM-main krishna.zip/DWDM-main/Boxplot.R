b <- c(10,12,13,14,17,19,20,30,50,70,90,100)
print(boxplot(b,col="green"))
