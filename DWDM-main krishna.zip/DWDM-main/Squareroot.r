x=as.integer(readline(prompt = "Enter the number"))
print((paste("Square root of",x,"is:",sqrt(x))))
