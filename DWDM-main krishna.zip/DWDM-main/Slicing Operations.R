s <-"Gowtham"
print(substring(s,1,1))
print(substring(s,1,5))
my_string <- "Hello, world!"

slice <- substr(my_string, 1, 5)
print(slice)

df<-c("Alok","Joseph","Hayato","Kelly","Paloma","Moca")
substring(df,4,4)<-c("$")
df


df<-("Saveetha_school_of_Engineering")
substring(df,1,11)
