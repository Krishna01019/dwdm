v <- c(17, 25, 38, 13, 41)
plot(v, type = "o")
