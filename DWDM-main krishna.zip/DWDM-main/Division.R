num1=as.integer(readline(prompt = "Enter the number 1:"))
num2 =as.integer(readline(prompt = "Enter a number2:"))
div=num1/num2
print((paste("Division:",div)))
