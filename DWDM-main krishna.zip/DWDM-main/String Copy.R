original_string <- "Welcome to SSE!!"
copy_string <- paste(original_string)
print(copy_string)

original_string <- "Welcome to SSE Family!!"
copy_string <- paste0(original_string)
print(copy_string)
