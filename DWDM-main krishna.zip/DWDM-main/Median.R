height <-c(150,174, 138, 186, 128, 136, 171, 163, 152, 131)
result.median <-median(height)
print(result.median)
