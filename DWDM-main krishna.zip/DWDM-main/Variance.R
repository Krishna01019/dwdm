X <- c(150,174, 138, 186, 128, 136, 171, 163, 152, 131) 
s <-var(X)
 print(paste("Variance:",s))
